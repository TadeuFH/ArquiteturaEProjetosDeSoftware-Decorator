package padroescomportamentais.chainofresponsability;

public interface TipoDocumento {
    
}
