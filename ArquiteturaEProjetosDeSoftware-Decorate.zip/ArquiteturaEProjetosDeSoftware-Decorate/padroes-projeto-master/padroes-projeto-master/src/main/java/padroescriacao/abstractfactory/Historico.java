package padroescriacao.abstractfactory;

public interface Historico {

    String emitir();
}
