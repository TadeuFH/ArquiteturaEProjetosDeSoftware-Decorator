package padroescriacao.abstractfactoryex1;

public interface FabricaAbstrata {

        Disciplina createDisciplina();;
        Nota createNota();
}

