package padroescriacao.prototypeex1;

public class HondaCivic extends Vehicle {
    public HondaCivic(int year) {
        super("Honda", "Civic", year);
    }

    public Vehicle clone() {
        return new HondaCivic(this.year);
    }
}
