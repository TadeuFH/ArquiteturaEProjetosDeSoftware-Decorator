package padroescriacao.abstractfactoryex1;

public interface Disciplina {
    String emitir();

}
