package padroescriacao.factorymethodex1;

public class Triangulo implements Poligono{
    public String getDescripition() {
        return "Triangulo";
    }
}
