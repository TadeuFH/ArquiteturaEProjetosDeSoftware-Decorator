package padroesestruturais.bridge;

public interface Escolaridade {

    float percentualAumento();
}
