package padroesestruturais.bridge;

public class Mestrado implements Escolaridade {

    public float percentualAumento() {
        return 0.2f;
    }
}
