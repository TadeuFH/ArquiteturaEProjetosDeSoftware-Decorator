package padroesestruturais.decoratorex1;

public abstract class HamburgerDecorator implements Hamburger {
    protected Hamburger hamburger;

    public HamburgerDecorator(Hamburger hamburger) {
        this.hamburger = hamburger;
    }

    public String getDescription() {
        return hamburger.getDescription();
    }

    public double getCost() {
        return hamburger.getCost();
    }
}
